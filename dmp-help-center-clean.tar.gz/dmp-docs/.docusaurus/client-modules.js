export default [
  require("/root/.openclaw/workspace/projects/dmp-help-center/dmp-docs/.docusaurus/docusaurus-plugin-css-cascade-layers/default/layers.css"),
  require("/root/.openclaw/workspace/projects/dmp-help-center/dmp-docs/node_modules/infima/dist/css/default/default.css"),
  require("/root/.openclaw/workspace/projects/dmp-help-center/dmp-docs/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/root/.openclaw/workspace/projects/dmp-help-center/dmp-docs/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/root/.openclaw/workspace/projects/dmp-help-center/dmp-docs/src/css/custom.css"),
];
