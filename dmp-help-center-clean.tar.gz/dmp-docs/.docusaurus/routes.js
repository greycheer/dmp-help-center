import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '3d7'),
    exact: true
  },
  {
    path: '/',
    component: ComponentCreator('/', '2e1'),
    exact: true
  },
  {
    path: '/',
    component: ComponentCreator('/', 'ce6'),
    routes: [
      {
        path: '/',
        component: ComponentCreator('/', '153'),
        routes: [
          {
            path: '/',
            component: ComponentCreator('/', 'a09'),
            routes: [
              {
                path: '/category/常见问题',
                component: ComponentCreator('/category/常见问题', 'c77'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/category/快速开始',
                component: ComponentCreator('/category/快速开始', '95c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/category/设备管理',
                component: ComponentCreator('/category/设备管理', '65b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/常见问题/设备离线排查',
                component: ComponentCreator('/常见问题/设备离线排查', 'b65'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/快速开始/创建项目',
                component: ComponentCreator('/快速开始/创建项目', '794'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/快速开始/平台简介',
                component: ComponentCreator('/快速开始/平台简介', 'ea5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/快速开始/账号注册',
                component: ComponentCreator('/快速开始/账号注册', 'fa3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/设备管理/批量导入',
                component: ComponentCreator('/设备管理/批量导入', '0af'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/设备管理/设备注册与激活',
                component: ComponentCreator('/设备管理/设备注册与激活', '7ca'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/',
                component: ComponentCreator('/', 'fc9'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
