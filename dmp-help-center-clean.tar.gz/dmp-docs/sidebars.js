// @ts-check

/** @type {import('@docusaurus/plugin-content-docs').SidebarsConfig} */
const sidebars = {
  tutorialSidebar: [
    'intro',
    {
      type: 'category',
      label: '快速开始',
      link: {
        type: 'generated-index',
        description: '5分钟上手DMP设备管理平台',
      },
      items: [
        '快速开始/平台简介',
        '快速开始/账号注册',
        '快速开始/创建项目',
      ],
    },
    {
      type: 'category',
      label: '设备管理',
      link: {
        type: 'generated-index',
        description: '设备全生命周期管理指南',
      },
      items: [
        '设备管理/设备注册与激活',
        '设备管理/批量导入',
      ],
    },
    {
      type: 'category',
      label: '用户权限',
      link: {
        type: 'generated-index',
        description: '角色与权限管理说明',
      },
      items: [],
    },
    {
      type: 'category',
      label: '增值服务',
      link: {
        type: 'generated-index',
        description: '增值服务购买与管理',
      },
      items: [],
    },
    {
      type: 'category',
      label: '开放接口',
      link: {
        type: 'generated-index',
        description: 'API文档与系统集成指南',
      },
      items: [],
    },
    {
      type: 'category',
      label: '常见问题',
      link: {
        type: 'generated-index',
        description: '故障排查与解决方案',
      },
      items: [
        '常见问题/设备离线排查',
      ],
    },
  ],
};

module.exports = sidebars;
